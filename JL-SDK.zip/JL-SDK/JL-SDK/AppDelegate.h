//
//  AppDelegate.h
//  JL-SDK
//
//  Created by Jasy on 16/1/6.
//  Copyright © 2016年 Jasy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

