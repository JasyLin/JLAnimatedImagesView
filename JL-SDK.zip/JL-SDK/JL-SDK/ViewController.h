//
//  ViewController.h
//  JL-SDK
//
//  Created by Jasy on 16/1/6.
//  Copyright © 2016年 Jasy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JLAnimatedImagesView.h"
@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet JLAnimatedImagesView *JLimageView;

@end

