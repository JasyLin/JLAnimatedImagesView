//
//  ViewController.m
//  JL-SDK
//
//  Created by Jasy on 16/1/6.
//  Copyright © 2016年 Jasy. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<JLAnimatedImagesViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.JLimageView.delegate = self;
    
    self.JLimageView.backgroundColor = [UIColor blackColor];
    [self.JLimageView startAnimating:JLAnimatedType_Largen];
    


    
    
}



-(NSInteger)animatedImagesNumberOfImages:(JLAnimatedImagesView *)animatedImagesView
{
    return 3;
}

-(UIImage *)animatedImagesView:(JLAnimatedImagesView *)animatedImagesView imageAtImdex:(NSInteger)index
{
    return [UIImage imageNamed:[NSString stringWithFormat:@"image%zi", index + 1]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
